#include <DHT.h>

// --- Pin setup ---
#define DHTPIN 6
#define DHTTYPE DHT11
#define LDR_PIN A0
#define PIR_PIN 3
#define LED_COOL 4
#define LED_WARM 5
#define LED_STATUS 13
#define LED_ALERT 12

// --- RGB LED pins ---
int redPin = 10;
int greenPin = 11;
int bluePin = 12;

// --- PIR calibration ---
int calibrationTime = 30;
long unsigned int lowIn;
long unsigned int pause = 5000;
boolean lockLow = true;
boolean takeLowTime;

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);

  // PIR setup
  pinMode(PIR_PIN, INPUT);
  pinMode(LED_STATUS, OUTPUT);
  digitalWrite(PIR_PIN, LOW);

  Serial.print("Calibrating PIR sensor ");
  for (int i = 0; i < calibrationTime; i++) {
    Serial.print(".");
    delay(1000);
  }
  Serial.println(" done");
  Serial.println("SENSOR ACTIVE");

  // DHT + LEDs setup
  dht.begin();
  pinMode(LED_COOL, OUTPUT);
  pinMode(LED_WARM, OUTPUT);
  pinMode(LED_ALERT, OUTPUT);

  // RGB LED setup
  pinMode(redPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(bluePin, OUTPUT);

  Serial.println("Smart Room Adaptive Hub starting...");
  delay(2000);
}

// Helper function to set RGB color
void setColor(bool r, bool g, bool b) {
  digitalWrite(redPin, r ? HIGH : LOW);
  digitalWrite(greenPin, g ? HIGH : LOW);
  digitalWrite(bluePin, b ? HIGH : LOW);
}

void loop() {
  // --- Motion detection ---
  if (digitalRead(PIR_PIN) == HIGH) {
    digitalWrite(LED_STATUS, HIGH);
    if (lockLow) {
      lockLow = false;
      Serial.println("---");
      Serial.print("Motion detected at ");
      Serial.print(millis() / 1000);
      Serial.println(" sec");
    }
    takeLowTime = true;
  }

  if (digitalRead(PIR_PIN) == LOW) {
    digitalWrite(LED_STATUS, LOW);
    if (takeLowTime) {
      lowIn = millis();
      takeLowTime = false;
    }
    if (!lockLow && millis() - lowIn > pause) {
      lockLow = true;
      Serial.print("Motion ended at ");
      Serial.print((millis() - pause) / 1000);
      Serial.println(" sec");
    }
  }

  // --- Climate sensing ---
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("DHT sensor error!");
    return;
  }

  if (temperature > 50.0) temperature = 0.0;
  if (humidity > 100.0) humidity = 0.0;

  Serial.print("Temp: ");
  Serial.print(temperature);
  Serial.print("C  Hum: ");
  Serial.print(humidity);
  Serial.print("%  ");

  // Climate mode logic
  if (temperature > 30.0) {
    digitalWrite(LED_COOL, HIGH);
    digitalWrite(LED_WARM, LOW);
    digitalWrite(LED_ALERT, HIGH);
    setColor(true, false, false); // Red
    Serial.print("Mode: HOT  ");
  } else if (temperature > 25.0) {
    digitalWrite(LED_COOL, LOW);
    digitalWrite(LED_WARM, HIGH);
    digitalWrite(LED_ALERT, LOW);
    setColor(true, true, false); // Yellow
    Serial.print("Mode: WARM  ");
  } else if (temperature >= 20.0) {
    setColor(false, true, false); // Green
    Serial.print("Mode: COMFORT  ");
  } else {
    setColor(false, false, true); // Blue
    Serial.print("Mode: COOL  ");
  }

  // --- Light sensing ---
  int lightRaw = analogRead(LDR_PIN);
  int lightPercent = map(lightRaw, 0, 1023, 0, 100);
  Serial.print("Light: ");
  Serial.print(lightPercent);
  Serial.print("%  ");

  Serial.print("Motion: ");
  Serial.println(digitalRead(PIR_PIN) == HIGH ? "YES" : "NO");

  delay(2000);
}

